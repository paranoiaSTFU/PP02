﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ClassLibraryForPracticeProduction
{
    public class ClassConvertToMD5
    {
        public static string ConvertToMD5(string a)//аргумент - строка которую надо перевести в MD5
        {
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] checkSum = md5.ComputeHash(Encoding.UTF8.GetBytes(a));
            string res = BitConverter.ToString(checkSum).Replace("-", String.Empty);
            return res.ToLower();
        }
    }
    public class CheckingForErrorsWhenFillingOut
    {
        public static string CheckingRegistration(string Login, string Password, string copy_password)
        {
            var errorString = new StringBuilder();
            var hasNumber = new Regex(@"[0-9]+");
            var hasUpperChar = new Regex(@"[A-Z]+");
            var hasCharLoginKir = new Regex(@"[А-Я-а-я]");
            var hasMiniMaxChars = new Regex(@".{6}");
            var hasSymbols = new Regex(@"[!@#$%^]");
            //проверка на пустые поля
            if (Login.Length == 0 || Password.Length == 0 || copy_password.Length == 0)
            {
                errorString.AppendLine("Вы не заполнили все поля");
            }
            //проверка на совпадение паролей
            else if(Password != copy_password)
            {
                errorString.AppendLine("Пароли не совпадают.");
            }
            //проверка на длину пароля
            else if (!hasMiniMaxChars.IsMatch(Password))
            {
                errorString.AppendLine("Пароль не должен быть меньше шести символов");
            }
            //проверка на длину логина
            else if (!hasMiniMaxChars.IsMatch(Login))
            {
                errorString.AppendLine("Логин не должен быть меньше шести символов");
            }
            //проверка на наличие прописных букв в пароле
            else if (!hasUpperChar.IsMatch(Password))
            {
                errorString.AppendLine("В пароле должна присутствовать хотя бы одна прописная буква");
            }
            //проверка на отсутствие кирилицы в логине
            else if (hasCharLoginKir.IsMatch(Login))
            {
                errorString.AppendLine("Логин должен состоять из букв латинского алфавита");
            }
            //проверка на присутствие цифр в пароле
            else if (!hasNumber.IsMatch(Password))
            {
                errorString.AppendLine("В пароле должна присутствовать хотя бы одна цифра");
            }
            //проверка на присутствие символов в пароле
            else if (!hasSymbols.IsMatch(Password))
            {
                errorString.AppendLine("В пароле должен присутствовать один символ из набора ( ! @ # $ % ^)");
            }

            if (errorString.Length > 0)
            {
                errorString.Insert(0, "Устраните ошибки: \n");
            }
            return errorString.ToString();
        }
        public static string CheckingErrorsAddEdit(string Name, string Type, string Quantity, string Description)
        {
            var errorString = new StringBuilder();

            if (Name.Length == 0 || Type.Length == 0 || Quantity.Length == 0 || Description.Length == 0)
            {
                errorString.AppendLine("Вы не заполнили все поля");
            }
            if (decimal.TryParse(Quantity, out decimal quantityD) == false)
            {
                errorString.AppendLine("Количество оборудования должно быть числом!");
            }
            if (decimal.TryParse(Quantity, out decimal quantity) == true && quantity < 0)
            {
                errorString.AppendLine("Количество оборудования не должно быть отрицательным!");
            }
            if (errorString.Length > 0)
            {
                errorString.Insert(0, "Устраните ошибки: \n");
            }
            return errorString.ToString();
        }
    }
}
