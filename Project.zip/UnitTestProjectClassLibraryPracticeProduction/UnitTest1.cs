﻿using ClassLibraryForPracticeProduction;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text;

namespace UnitTestProjectClassLibraryPracticeProduction
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod_ConvertToMD5()
        {
            string a = "Текст для кодировки";
            Assert.AreEqual(ClassConvertToMD5.ConvertToMD5(a), "5d2f1166382e1f870e7581607ffba685");
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Login_Length_False()
        {
            string Login = "Login";
            string Password = "Password01!";
            string PasswordCopy = "Password01!";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);

            var res = new StringBuilder();
            res.AppendLine("Логин не должен быть меньше шести символов");
            res.Insert(0, "Устраните ошибки: \n");

            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Login_Length_True()
        {
            string res = "Логин не должен быть меньше шести символов";
            string Login = "LoginNormal01!";
            string Password = "Password01!";
            string PasswordCopy = "Password01!";
            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);
            if(ErrorMesseg.Length==0)
                res = "Пользователь успешно зарегистрирован.";
            Assert.AreEqual(res, "Пользователь успешно зарегистрирован.");
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Login_Fill_False()
        {
            string Login = "";
            string Password = "Password01!";
            string PasswordCopy = "";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);

            StringBuilder res = new StringBuilder();
            res.AppendLine("Вы не заполнили все поля");
            res.Insert(0, "Устраните ошибки: \n");


            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Login_Fill_True()
        {
            string res = "Вы не заполнили все поля";
            string Login = "LoginNormal01!";
            string Password = "Password01!";
            string PasswordCopy = "Password01!";
            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);
            if (ErrorMesseg.Length == 0)
                res = "Пользователь успешно зарегистрирован.";
            Assert.AreEqual(res, "Пользователь успешно зарегистрирован.");
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Copy_Password_False()
        {
            string Login = "LoginNormal1!";
            string Password = "Password01!";
            string PasswordCopy = "Пароль01!";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);

            StringBuilder res = new StringBuilder();
            res.AppendLine("Пароли не совпадают.");
            res.Insert(0, "Устраните ошибки: \n");


            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Copy_Password_True()
        {
            string res = "Пароли не совпадают.";
            string Login = "LoginOnTest";
            string Password = "Password01!";
            string PasswordCopy = "Password01!";
            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);
            if (ErrorMesseg.Length == 0)
                res = "Пользователь успешно зарегистрирован.";
            Assert.AreEqual(res, "Пользователь успешно зарегистрирован.");
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Password_Length_False()
        {
            string Login = "LoginNormal1!";
            string Password = "Pas1!";
            string PasswordCopy = "Pas1!";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);

            StringBuilder res = new StringBuilder();
            res.AppendLine("Пароль не должен быть меньше шести символов");
            res.Insert(0, "Устраните ошибки: \n");


            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Password_Length_True()
        {
            string res = "Пароль не должен быть меньше шести символов";
            string Login = "LoginOnTest";
            string Password = "PasswordOnTest01!";
            string PasswordCopy = "PasswordOnTest01!";
            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);
            if (ErrorMesseg.Length == 0)
                res = "Пользователь успешно зарегистрирован.";
            Assert.AreEqual(res, "Пользователь успешно зарегистрирован.");
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Password_Char_False()
        {
            string Login = "LoginNormal1!";
            string Password = "a123456!";
            string PasswordCopy = "a123456!";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);

            StringBuilder res = new StringBuilder();
            res.AppendLine("В пароле должна присутствовать хотя бы одна прописная буква");
            res.Insert(0, "Устраните ошибки: \n");


            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Password_Char_True()
        {
            string res = "В пароле должна присутствовать хотя бы одна прописная буква";
            string Login = "LoginOnTest";
            string Password = "PasswordOnTest01!";
            string PasswordCopy = "PasswordOnTest01!";
            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);
            if (ErrorMesseg.Length == 0)
                res = "Пользователь успешно зарегистрирован.";
            Assert.AreEqual(res, "Пользователь успешно зарегистрирован.");
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Login_No_Char_RU_False()
        {
            string Login = "ЭтоМойЛгин1!";
            string Password = "A123456!";
            string PasswordCopy = "A123456!";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);

            StringBuilder res = new StringBuilder();
            res.AppendLine("Логин должен состоять из букв латинского алфавита");
            res.Insert(0, "Устраните ошибки: \n");


            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Login_No_Char_RU_True()
        {
            string res = "Логин должен состоять из букв латинского алфавита";
            string Login = "LoginOnTest";
            string Password = "PasswordOnTest01!";
            string PasswordCopy = "PasswordOnTest01!";
            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);
            if (ErrorMesseg.Length == 0)
                res = "Пользователь успешно зарегистрирован.";
            Assert.AreEqual(res, "Пользователь успешно зарегистрирован.");
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Int_in_Password_False()
        {
            string Login = "MyLogin!";
            string Password = "MyPassword!";
            string PasswordCopy = "MyPassword!";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);

            StringBuilder res = new StringBuilder();
            res.AppendLine("В пароле должна присутствовать хотя бы одна цифра");
            res.Insert(0, "Устраните ошибки: \n");


            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Int_in_Password_True()
        {
            string res = "В пароле должна присутствовать хотя бы одна цифра";
            string Login = "LoginOnTest";
            string Password = "PasswordOnTest01!";
            string PasswordCopy = "PasswordOnTest01!";
            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);
            if (ErrorMesseg.Length == 0)
                res = "Пользователь успешно зарегистрирован.";
            Assert.AreEqual(res, "Пользователь успешно зарегистрирован.");
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Special_Char_in_Password_False()
        {
            string Login = "MyLogin!";
            string Password = "MyPassword1";
            string PasswordCopy = "MyPassword1";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);

            StringBuilder res = new StringBuilder();
            res.AppendLine("В пароле должен присутствовать один символ из набора ( ! @ # $ % ^)");
            res.Insert(0, "Устраните ошибки: \n");


            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingRegistration_Special_Char_in_Password_True()
        {
            string res = "В пароле должен присутствовать один символ из набора ( ! @ # $ % ^)";
            string Login = "LoginOnTest";
            string Password = "PasswordOnTest01!";
            string PasswordCopy = "PasswordOnTest01!";
            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login, Password, PasswordCopy);
            if (ErrorMesseg.Length == 0)
                res = "Пользователь успешно зарегистрирован.";
            Assert.AreEqual(res, "Пользователь успешно зарегистрирован.");
        }
        [TestMethod]
        public void TestMethod_CheckingErrorsAddEdit_Zapolnenie_False()
        {
            string Name = "Удленитель USB";
            string ComboBoxType = "";
            string Quantity = "5";
            string Description = "Удлинитель USB на USB, Male-Male, 2 метра";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingErrorsAddEdit(Name, ComboBoxType, Quantity, Description);

            StringBuilder res = new StringBuilder();
            res.AppendLine("Вы не заполнили все поля");
            res.Insert(0, "Устраните ошибки: \n");

            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingErrorsAddEdit_Zapolnenie_True()
        {
            string res = "Вы не заполнили все поля";

            string Name = "Удленитель USB";
            string ComboBoxType = "Провода";
            string Quantity = "5";
            string Description = "Удлинитель USB на USB, Male-Male, 2 метра";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingErrorsAddEdit(Name, ComboBoxType, Quantity, Description);

            if (ErrorMesseg.Length == 0)
                res = "Сохранено";

            Assert.AreEqual<string>(res, "Сохранено");
        }
        [TestMethod]
        public void TestMethod_CheckingErrorsAddEdit_Quantity_its_chislo_False()
        {
            string Name = "Удленитель USB";
            string ComboBoxType = "Провода";
            string Quantity = "Пять";
            string Description = "Удлинитель USB на USB, Male-Male, 2 метра";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingErrorsAddEdit(Name, ComboBoxType, Quantity, Description);

            StringBuilder res = new StringBuilder();
            res.AppendLine("Количество оборудования должно быть числом!");
            res.Insert(0, "Устраните ошибки: \n");

            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingErrorsAddEdit_Quantity_Its_Chislo_True()
        {
            string res = "Кол-во должно быть числом";

            string Name = "Удленитель USB";
            string ComboBoxType = "Провода";
            string Quantity = "5";
            string Description = "Удлинитель USB на USB, Male-Male, 2 метра";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingErrorsAddEdit(Name, ComboBoxType, Quantity, Description);

            if (ErrorMesseg.Length == 0)
                res = "Сохранено";

            Assert.AreEqual<string>(res, "Сохранено");
        }
        [TestMethod]
        public void TestMethod_CheckingErrorsAddEdit_Quantity_Its_Not_Negative_Chislo_False()
        {
            string Name = "Удленитель USB";
            string ComboBoxType = "Провода";
            string Quantity = "-5";
            string Description = "Удлинитель USB на USB, Male-Male, 2 метра";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingErrorsAddEdit(Name, ComboBoxType, Quantity, Description);

            StringBuilder res = new StringBuilder();
            res.AppendLine("Количество оборудования не должно быть отрицательным!");
            res.Insert(0, "Устраните ошибки: \n");

            Assert.AreEqual<string>(ErrorMesseg, res.ToString());
        }
        [TestMethod]
        public void TestMethod_CheckingErrorsAddEdit_Quantity_Its_Not_Negative_Chislo_True()
        {
            string res = "Кол-во должно быть не отрицателным числом";

            string Name = "Удленитель USB";
            string ComboBoxType = "Провода";
            string Quantity = "5";
            string Description = "Удлинитель USB на USB, Male-Male, 2 метра";

            string ErrorMesseg = CheckingForErrorsWhenFillingOut.CheckingErrorsAddEdit(Name, ComboBoxType, Quantity, Description);

            if (ErrorMesseg.Length == 0)
                res = "Сохранено";

            Assert.AreEqual<string>(res, "Сохранено");
        }
    }
}
