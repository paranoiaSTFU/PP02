﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using ClassLibraryForPracticeProduction;
namespace Practice_Production.Pages
{
    /// <summary>
    /// Логика взаимодействия для Autorisation.xaml
    /// </summary>
    public partial class Autorisation : Page
    {
        public string PasswordString = "";
        public Autorisation()
        {
            InitializeComponent();
        }
        public void Enter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string InputPassword = ClassConvertToMD5.ConvertToMD5(PasswordHiden.Password);
                var auto = App.Context.Users.Where(p => p.Login == Login.Text && p.Password == InputPassword).FirstOrDefault();
                if (Login.Text.Length == 0 || PasswordHiden.Password.Length == 0)
                {
                    MessageBox.Show("Вы не заполнили все поля.",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                else if (auto == null)
                {
                    MessageBox.Show("Такого пользователя нет. Пожалуйста, проверьте правильность ввода данных аккаунта, или зарегестрируйтесь.",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                else
                {
                    MessageBox.Show("Вы зашли как: " + auto.Login,"Успех",MessageBoxButton.OK,MessageBoxImage.Information);
                    NavigationService.Navigate(new Pages.PageStore());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка" + ex, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        public void Registration_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Pages.Registration());
        }
        private void CheckPassword_Checked(object sender, RoutedEventArgs e)
        {
            if (CheckPassword.IsChecked==true)
            {
                PasswordHiden.Visibility = Visibility.Hidden;
                PasswordString = PasswordHiden.Password;
                Password.Text = PasswordString;
                Password.Visibility = Visibility.Visible;
            }
            else
            {                
                Password.Visibility = Visibility.Hidden;
                PasswordHiden.Visibility = Visibility.Visible;
            }
        }
    }
}