﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ClassLibraryForPracticeProduction;

namespace Practice_Production.Pages
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Page
    {
        public Registration()
        {
            InitializeComponent();
        }

        public void Registr_Click(object sender, RoutedEventArgs e)
        { 
            try
            {
                var errorMessage = CheckingForErrorsWhenFillingOut.CheckingRegistration(Login.Text, Password.Text, CopyPassword.Text);
                //проверка на ошибки
                if (errorMessage.Length > 0)
                {
                    MessageBox.Show(errorMessage, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                //проверка на наличие логина в базе
                if (App.Context.Users.Count(p => p.Login == Login.Text) > 0)
                {
                    MessageBox.Show("Данный логин уже существует.");
                    return;
                }
                string result = ClassConvertToMD5.ConvertToMD5(Password.Text);
                Entity.User user = new Entity.User()
                {
                    Login = Login.Text,
                    Password = result
                };
                App.Context.Users.Add(user);
                App.Context.SaveChanges();
                MessageBox.Show("Пользователь успешно зарегестрирован.");
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка" + ex);
            }
            
        }
        public void Cancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}