﻿using Practice_Production.Entity;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace Practice_Production.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageStore.xaml
    /// </summary>
    public partial class PageStore : Page
    {
        public PageStore()
        {
            InitializeComponent();
            ComboFiltr.ItemsSource = App.Context.Types.Select(p => p.Name).ToList();
            ComboFiltr.SelectedIndex = 0;    
            ComboSort.SelectedIndex = 0;
        }

        public void Update()
        {
            try
            {
                var render = App.Context.Products.ToList();

                //Поиск
                render = render.Where(p => p.Name.ToLower().Contains(Search.Text.ToLower())).ToList();

                //Сортировка
                if (ComboSort.SelectedIndex == 0)
                    render = render.DefaultIfEmpty().ToList();
                if (ComboSort.SelectedIndex == 1)
                    render = render.OrderBy(p => p.Quantity).ToList();
                if (ComboSort.SelectedIndex == 2)
                    render = render.OrderByDescending(p => p.Quantity).ToList();
                //Фильтрация
                if (render.Where(p => p.Type.Name.ToLower() == ComboFiltr.SelectedItem.ToString().ToLower()).ToList() == null)
                {
                    MessageBox.Show("Данного товара нет", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                else
                    render = render.Where(p => p.Type.Name.ToLower() == ComboFiltr.SelectedItem.ToString().ToLower()).ToList();
                ListProduct.ItemsSource = render;
            }
            catch (Exception e)
            { MessageBox.Show(e.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error); }
            
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Pages.AddEditProduct());
            Update();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            var edit = (sender as Button).DataContext as Entity.Product;
            NavigationService.Navigate(new Pages.AddEditProduct(edit));
        }

        private void ComboFiltr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void ComboSort_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Update();
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            Update();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show($"Вы действительно хотите выйти?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                NavigationService.Navigate(new Pages.Autorisation());
            }
        }
    }
}
