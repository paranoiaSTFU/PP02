﻿using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using ClassLibraryForPracticeProduction;
namespace Practice_Production.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditProduct.xaml
    /// </summary>
    public partial class AddEditProduct : Page
    {
        public Entity.Product _product = null;
        public AddEditProduct()
        {
            InitializeComponent();
            ComboBoxType.ItemsSource = App.Context.Types.Select(p => p.Name).ToList();
        }
        public AddEditProduct(Entity.Product product)
        {
            InitializeComponent();
            ComboBoxType.ItemsSource = App.Context.Types.Select(p => p.Name).ToList();
            _product = product;
            Name.Text = _product.Name;
            Quantity.Text = _product.Quantity.ToString();
            ComboBoxType.SelectedIndex = (int)_product.IDType - 1;
            Description.Text = _product.Description;
        }
        public void Save_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var errorMessage = CheckingForErrorsWhenFillingOut.CheckingErrorsAddEdit(Name.Text, ComboBoxType.Text, Quantity.Text, Description.Text);

                if (errorMessage.Length > 0)
                {
                    MessageBox.Show(errorMessage, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (_product == null)
                    {
                        var _Product = new Entity.Product
                        {
                            Name = Name.Text,
                            Quantity = Convert.ToInt32(Quantity.Text),
                            IDType = ComboBoxType.SelectedIndex + 1,
                            Description = Description.Text,
                        };

                        App.Context.Products.Add(_Product);
                        App.Context.SaveChanges();
                        MessageBox.Show("Товар успешно добавлен", "Добавление записи", MessageBoxButton.OK, MessageBoxImage.Information);
                        NavigationService.Navigate(new Pages.PageStore());
                    }
                    else
                    {
                        _product.Name = Name.Text;
                        _product.Quantity = Convert.ToInt32(Quantity.Text);
                        _product.IDType = ComboBoxType.SelectedIndex + 1;
                        _product.Description = Description.Text;

                        MessageBox.Show("Запись изменена!", "Редактирование записи", MessageBoxButton.OK, MessageBoxImage.Information);
                        App.Context.SaveChanges();
                        NavigationService.Navigate(new Pages.PageStore());
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка" + ex);
            }
        }
        public void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show($"Вы хотите удалить продукт {_product.Name}?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                App.Context.Products.Remove(_product);
                App.Context.SaveChanges();
                NavigationService.Navigate(new Pages.PageStore());
            }
        }
        public void PaintProd_Click(object sender, RoutedEventArgs e)
        {
            Description.TextWrapping = TextWrapping.NoWrap;

            NavigationService.Navigate(new Pages.SpecificReceipt(Name.Text, ComboBoxType.Text, Quantity.Text, Description.Text));
        }

        public void Cancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}