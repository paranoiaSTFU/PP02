﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Printing;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Practice_Production.Pages
{
    /// <summary>
    /// Логика взаимодействия для SpecificReceipt.xaml
    /// </summary>
    public partial class SpecificReceipt : Page
    {
        public SpecificReceipt()
        {
            InitializeComponent();
        }

        public SpecificReceipt(string name, string type, string quantity, string description)
        {
            InitializeComponent();

            Name.Content = name;
            Type.Content = type;
            Quantity.Content = quantity;
            Description.Content = description;
        }

        public static void PrintCheck(Visual elementToPrint, string something)
        {
            using (var printServer = new LocalPrintServer())
            {
                var dialog = new PrintDialog();
                var qs = printServer.GetPrintQueues();
                dialog.PrintTicket.PageOrientation = PageOrientation.Portrait;
                dialog.PrintVisual(elementToPrint, something);
            } 
        }

        public void Print_Click(object sender, RoutedEventArgs e)
        {
            Print.Visibility = Visibility.Hidden;
            PrintCheck(this, Convert.ToString(Name.Content));
            NavigationService.GoBack();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
