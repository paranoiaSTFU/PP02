﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_Production.Entity
{
    public partial class Product
    {
        public string Names
        {
            get
            {
                return "Наименование товара:\n" + Name;
            }
        }

        public string Quantities
        {
            get 
            {
                return "Количество: " + Quantity; 
            }
        }

        public string BgColor
        {
            get
            {
                if (Quantity == 0)
                {
                    return "#808080";
                }
                else
                {
                    return "#ffffff";
                }
            }
        }
    }
}
